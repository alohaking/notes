CREATE DATABASE IF NOT EXISTS backend default charset utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE TABLE `user`(
	`id` bigint(20) not null PRIMARY key auto_increment comment '主键',
	`account` varchar(32) not null comment '用户账号',
	`name` varchar(64) not null comment '用户名',
	`password` varchar(256) null comment '用户密码',
	`status` smallint not null default 1 comment '用户状态,1:正常;0:冻结',
	`salt` varchar(32) null comment '用户盐值',
	`token_salt` varchar(32) null comment '登录盐值',
	`create_time` DATETIME not null comment '创建时间',
	`update_time` DATETIME null comment '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户信息';
create UNIQUE index idx_account on `user`(`account`);
insert into `user`(`account`,`name`,`password`,`salt`,`create_time`,`update_time`) values
	('wanghengxian','王恒先','6f92b96529c5587de23c891a6fcad33077fa8b9d11a44c4574e70b97b9af19a9','6268477f89d71c92c4a9830304ff32ca',now(),now());
