package tech.qdhxy.backend.web;

import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import tech.qdhxy.backend.domain.User;
import tech.qdhxy.backend.exceptions.BizException;
import tech.qdhxy.backend.service.UserService;
import tech.qdhxy.backend.utils.JwtUtils;
import tech.qdhxy.backend.web.request.UserLoginReq;
import tech.qdhxy.backend.web.response.CurrentUser;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api")
public class CommonController {

    private UserService userService;
    private String imgDir;
    private String imgUrl;

    private final static List<String> IMAGE_TYPES = Arrays.asList("jpg", "png", "jpeg", "mp4");

    @Autowired
    public CommonController(UserService userService,
                            @Value("${img.path}") String imgDir,
                            @Value("${img.url}") String imgUrl) {
        this.userService = userService;
        this.imgDir = imgDir;
        this.imgUrl = imgUrl;
    }

    /**
     * 用户登录
     * @param req
     */
    @PostMapping("/login")
    public void login(@Valid @RequestBody UserLoginReq req, HttpServletResponse response){
        log.debug("login with user :{}", req);

        Subject subject = SecurityUtils.getSubject();
        AuthenticationToken token = null;
        token = new UsernamePasswordToken(req.getAccount(), req.getPassword());
        try {
            subject.login(token);
        }catch (Exception e){
            throw new BizException("用户名或者密码错误");
        }
        User user = (User) subject.getPrincipal();
        String newToken = userService.generateJwtToken(user.getAccount());
        response.setHeader(JwtUtils.AUTH_HEADER, JwtUtils.HEADER_TOKEN_VAL + newToken);
    }

    @GetMapping("/me")
    public CurrentUser getMe(){
        return JwtUtils.getMe().map(CurrentUser::of).orElseThrow(() -> new AuthenticationException());
    }

    /**
     * 退出当前登录用户
     */
    @PostMapping("/logout")
    public void logout(){
        JwtUtils.getMe().ifPresent(userService::logout);
        SecurityUtils.getSubject().logout();
    }

    @PostMapping("/upload")
    public String upload(@RequestParam("file") MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            throw new BizException("上传图片不能为空");
        }
        String oName = file.getOriginalFilename();
        int dotIndex = oName.lastIndexOf(".");
        if(dotIndex < 0){
            throw new BizException("图片格式不正确");
        }
        String ext = oName.substring(dotIndex);
        boolean flag = false;
        for (String imgType : IMAGE_TYPES) {
            if (StringUtils.endsWithIgnoreCase(ext, imgType)) {
                flag = true;
                break;
            }
        }
        if (!flag) {
            throw new BizException("图片格式不正确");
        }
        String fileName = JwtUtils.generateSalt() + ext;
        String path = imgDir + fileName;
        Path dest = Paths.get(path);
        file.transferTo(dest);
        return imgUrl + fileName;
    }
}
