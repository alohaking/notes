package tech.qdhxy.backend.enums;

public enum StatusType {
    NORMAL,FROZEN
}
