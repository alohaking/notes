package tech.qdhxy.backend.domain;

import lombok.Data;

@Data
public class User extends BaseEntity{
    private String name;
    private String account;
    private String password;
    private String salt;
    private String tokenSalt;
    private Integer status;//状态
}
