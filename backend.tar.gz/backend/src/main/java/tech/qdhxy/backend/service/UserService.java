package tech.qdhxy.backend.service;

import tech.qdhxy.backend.domain.User;

import java.util.Optional;

public interface UserService {
    Optional<User> getUserByAccount(String account);
    /**
     * 登录，生成token
     * @param account
     * @return
     */
    String generateJwtToken(String account);

    void logout(User user);
}
