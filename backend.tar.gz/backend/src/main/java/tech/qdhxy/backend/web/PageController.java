package tech.qdhxy.backend.web;

import lombok.extern.slf4j.Slf4j;
import me.chanjar.weixin.mp.bean.result.WxMpUser;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Slf4j
@Controller
@RequestMapping("/page")
public class PageController extends WxAuthorizeController {

    @RequestMapping("/hello")
    public String hello(@RequestParam(required = false) String code,
                        HttpServletRequest request,
                        HttpServletResponse response) {
        WxMpUser wxUser = this.authorize(code, request, response);
        return "hello";
    }
}
