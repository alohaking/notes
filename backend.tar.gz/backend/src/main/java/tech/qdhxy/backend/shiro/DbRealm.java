package tech.qdhxy.backend.shiro;

import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.authc.*;
import org.apache.shiro.authc.credential.HashedCredentialsMatcher;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import tech.qdhxy.backend.service.UserService;

import java.util.Optional;

@Slf4j
public class DbRealm extends AuthorizingRealm {

    private UserService userService;

    public DbRealm(UserService userService) {
        this.userService = userService;
        this.setCredentialsMatcher(new HashedCredentialsMatcher(Sha256Hash.ALGORITHM_NAME));
    }

    public static void main(String[] args) {
        Sha256Hash hash = new Sha256Hash("wanghengxian", "6268477f89d71c92c4a9830304ff32ca");
        System.out.println(hash.toString());
    }

    /**
     * 当有多个Realm，且需要根据token区分时，需要重载此方法
     *
     * @param token
     * @return
     */
    @Override
    public boolean supports(AuthenticationToken token) {
        return token instanceof UsernamePasswordToken;
    }

    /**
     * 登录认证，只有/api/login请求会调用此方法。
     * subject.login(token)最终会调用此方法
     *
     * @param token
     * @return
     * @throws AuthenticationException
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token)
            throws AuthenticationException {
        UsernamePasswordToken userPasswordToken = (UsernamePasswordToken) token;
        String userAccount = userPasswordToken.getUsername();

        Optional<SimpleAuthenticationInfo> opt = userService.getUserByAccount(userAccount).map(user -> new SimpleAuthenticationInfo(user, user.getPassword(), ByteSource.Util.bytes(user.getSalt()), "dbRealm"));

        if(opt.isPresent()) {
            return opt.get();
        } else {
            throw new RuntimeException();
        }
    }

    /**
     * 角色、权限认证，subject.checkRole() 、subject.checkPermission()等最终会调用此方法
     *
     * @param principals
     * @return
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        SimpleAuthorizationInfo simpleAuthorizationInfo = new SimpleAuthorizationInfo();
        //User user = (User) principals.getPrimaryPrincipal();
        //simpleAuthorizationInfo.addRole("role");

        //TODO 添加用户角色对应的权限

        //List<String> permissions = null;
        //simpleAuthorizationInfo.addStringPermissions(permissions);

        return simpleAuthorizationInfo;
    }
}
