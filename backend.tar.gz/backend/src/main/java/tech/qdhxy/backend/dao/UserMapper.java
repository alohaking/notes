package tech.qdhxy.backend.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import tech.qdhxy.backend.domain.User;

public interface UserMapper extends BaseMapper<User> {
}
