package tech.qdhxy.backend.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tech.qdhxy.backend.dao.UserMapper;
import tech.qdhxy.backend.domain.User;
import tech.qdhxy.backend.service.UserService;
import tech.qdhxy.backend.utils.JwtUtils;

import java.util.Optional;

@Service
public class UserServiceImpl extends CommonServiceImpl<Long, User> implements UserService {
    private static final String FIELD_ACCOUNT = "account";

    private UserMapper userMapper;

    @Autowired
    public UserServiceImpl(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    public Optional<User> getUserByAccount(String account) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq(FIELD_ACCOUNT, account);
        this.selectOne(wrapper);
        return Optional.empty();
    }

    @Override
    public String generateJwtToken(String account) {
        String tokenSalt = JwtUtils.generateSalt();

        this.getUserByAccount(account).map(user -> {
            user.setTokenSalt(tokenSalt);
            return user;
        }).ifPresent(userMapper::updateById);

        // 生成jwt token，设置过期时间为1小时
        return JwtUtils.sign(account, tokenSalt);
    }

    @Override
    public void logout(User user) {
        this.getUserByAccount(user.getAccount()).map(x -> {
            x.setTokenSalt("");
            return x;
        }).ifPresent(userMapper::updateById);
    }
}
