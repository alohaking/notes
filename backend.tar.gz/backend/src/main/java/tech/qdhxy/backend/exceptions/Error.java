package tech.qdhxy.backend.exceptions;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Error {
    public static final int BIZ_CODE = 600;
    public static final int PARA_ERROR_CODE = 601;
    public static final int AUTH_ERROR_CODE = 602;
    public static final int SERVER_ERROR_CODE = 603;
    private int code;
    private String msg;

    public static final Error of(int code, String msg) {
        return new Error(code, msg);
    }
}
