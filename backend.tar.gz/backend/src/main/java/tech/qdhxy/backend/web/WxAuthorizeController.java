package tech.qdhxy.backend.web;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import me.chanjar.weixin.common.error.WxErrorException;
import me.chanjar.weixin.mp.api.WxMpService;
import me.chanjar.weixin.mp.bean.result.WxMpOAuth2AccessToken;
import me.chanjar.weixin.mp.bean.result.WxMpUser;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Objects;

@Slf4j
public class WxAuthorizeController {
    @Autowired
    private WxMpService wxMpService;

    @Value("${isDev}")
    private boolean isDev;

    protected WxMpUser authorize(String code, HttpServletRequest request, HttpServletResponse response) {
        WxMpUser wxUser = null;
        StringBuffer sb = request.getRequestURL();
        if(StringUtils.isNotBlank(request.getQueryString())) {
            sb.append("?").append(request.getQueryString());
        }
        log.info("redirect_url = {}", sb.toString());
        if(Objects.isNull(code)) {
            String redirectUrl = wxMpService.oauth2buildAuthorizationUrl(sb.toString(), "snsapi_userinfo", null);
            try {
                response.sendRedirect(redirectUrl);
            } catch (IOException e) {
                log.error("authorize error", e);
            }
        } else {
            try {
                if (!isDev) {
                    WxMpOAuth2AccessToken token = wxMpService.oauth2getAccessToken(code);
                    wxUser = wxMpService.oauth2getUserInfo(token, null);
                } else {
                    wxUser = new WxMpUser();
                    wxUser.setOpenId("11111");
                    wxUser.setNickname("dump");
                }
                log.debug("get wx user info: {}", JSON.toJSONString(wxUser));
            } catch (WxErrorException e) {
                log.error("get wx user info error", e);
                String remove = "code=" + code;
                String url = sb.toString().replaceAll(remove, "");
                try {
                    response.sendRedirect(url);
                } catch (IOException e1) {
                    // ignore
                }
            }
        }
        return wxUser;
    }
}
