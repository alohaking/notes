package tech.qdhxy.backend.filters;

import lombok.extern.slf4j.Slf4j;
import me.chanjar.weixin.mp.util.WxMpConfigStorageHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Objects;

@Slf4j
@Component
public class WxFilter implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String appId = request.getParameter("appId");
        if(Objects.nonNull(appId)) {
            WxMpConfigStorageHolder.set(appId);
        }
        return true;
    }
}
