package tech.qdhxy.backend.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.factory.annotation.Autowired;
import tech.qdhxy.backend.domain.BaseEntity;
import tech.qdhxy.backend.service.CommonService;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public abstract class CommonServiceImpl<K extends Serializable, T extends BaseEntity> implements CommonService<K, T> {
    @Autowired
    private BaseMapper<T> mapper;

    @Override
    public T selectByKey(K key) {
        return mapper.selectById(key);
    }

    @Override
    public T selectOne(Wrapper<T> wrapper) {
        return mapper.selectOne(wrapper);
    }

    @Override
    public int save(T entity) {
        if(Objects.isNull(entity.getId())) {
            return mapper.insert(entity);
        } else {
            return mapper.updateById(entity);
        }
    }

    @Override
    public int delete(K key) {
        return mapper.deleteById(key);
    }

    @Override
    public List<T> selectList(Wrapper<T> wrapper) {
        return mapper.selectList(wrapper);
    }

    @Override
    public IPage<T> selectPage(int pageNum, int pageSize, Wrapper<T> wrapper) {
        IPage<T> page = new Page<>(pageNum, pageSize);
        return mapper.selectPage(page, wrapper);
    }
}
