package tech.qdhxy.backend.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.crypto.SecureRandomNumberGenerator;
import org.apache.shiro.subject.Subject;
import tech.qdhxy.backend.domain.User;

import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;

@Slf4j
public final class JwtUtils {
    private JwtUtils() {

    }

    public static final String USER_ACCOUNT = "account";
    public static final String AUTH_HEADER = "Authorization";
    public static final String HEADER_TOKEN_VAL = "Bearer ";

    /**
     * 获得token中的信息无需secret解密也能获得
     *
     * @param token
     * @return token中包含的签发时间
     */
    public static Optional<Date> getIssuedAt(String token) {
        try {
            DecodedJWT jwt = JWT.decode(token);
            return Optional.ofNullable(jwt.getIssuedAt());
        } catch (JWTDecodeException e) {
            logDecodeError(e);
        }
        return Optional.empty();
    }

    /**
     * 获得token中的信息无需secret解密也能获得
     *
     * @param token
     * @return token中包含的用户名
     */
    public static String getUserAccount(String token) {
        try {
            DecodedJWT jwt = JWT.decode(token);
            return jwt.getClaim(USER_ACCOUNT).asString();
        } catch (JWTDecodeException e) {
            logDecodeError(e);
        }
        return null;
    }

    private static void logDecodeError(JWTDecodeException e) {
        log.error("jwt decode error", e);
    }

    /**
     * 生成签名,expireTime后过期
     *
     * @param userAccount 用户名
     * @return 加密的token
     */
    public static String sign(String userAccount, String salt) {
        try {
            //Date date = new Date(System.currentTimeMillis() + time * 1000);
            Algorithm algorithm = Algorithm.HMAC256(salt);
            // 附带username信息
            String sign = JWT.create()
                    .withClaim(USER_ACCOUNT, userAccount)
                    .withIssuedAt(new Date())
                    .sign(algorithm);
            return sign;
        } catch (UnsupportedEncodingException e) {
            log.error("unsupported encoding", e);
        }
        return null;
    }

    /**
     * token是否过期
     *
     * @param token
     * @return true：过期
     */
    public static boolean isTokenExpired(String token) {
        Date now = Calendar.getInstance().getTime();
        DecodedJWT jwt = JWT.decode(token);
        return jwt.getExpiresAt().before(now);
    }

    /**
     * 生成随机盐,长度32位
     *
     * @return
     */
    public static String generateSalt() {
        SecureRandomNumberGenerator secureRandom = new SecureRandomNumberGenerator();
        String hex = secureRandom.nextBytes(16).toHex();
        return hex;
    }

    public static Optional<User> getMe() {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        return Optional.ofNullable(user);
    }
}
