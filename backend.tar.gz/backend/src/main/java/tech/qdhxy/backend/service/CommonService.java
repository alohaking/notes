package tech.qdhxy.backend.service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import tech.qdhxy.backend.domain.BaseEntity;

import java.io.Serializable;
import java.util.List;

public interface CommonService<K extends Serializable, T extends BaseEntity> {
    T selectByKey(K key);

    T selectOne(Wrapper<T> wrapper);

    int save(T entity);

    int delete(K key);

    List<T> selectList(Wrapper<T> wrapper);

    IPage<T> selectPage(int pageNum, int pageSize, Wrapper<T> wrapper);
}
