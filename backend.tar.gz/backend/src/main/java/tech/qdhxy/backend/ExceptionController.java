package tech.qdhxy.backend;

import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.authz.UnauthorizedException;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.util.ContentCachingRequestWrapper;
import tech.qdhxy.backend.exceptions.*;
import tech.qdhxy.backend.exceptions.Error;

import javax.servlet.ServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.nio.charset.Charset;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@ControllerAdvice
class ExceptionController {

    /**
     * 业务异常
     *
     * @param ex
     * @return
     */
    @ExceptionHandler(BizException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    Error bizExceptionHandler(BizException ex) {
        return Error.of(Error.BIZ_CODE, ex.getMsg());
    }

    /**
     * 参数验证
     *
     * @param ex
     * @return
     */
    @ExceptionHandler({ConstraintViolationException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    Error validationHandler(ConstraintViolationException ex) {
        log.error(   "单个参数校验异常",ex);
        List<String> defaultMsg = ex.getConstraintViolations()
                .stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.toList());
        return Error.of(Error.PARA_ERROR_CODE, defaultMsg.get(0));
    }

    /**
     * 参数验证
     *
     * @param ex
     * @return
     */
    @ExceptionHandler({BindException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    Error validationHandler(BindException ex) {
        log.error("参数校验异常",ex);
        List<String> defaultMsg = ex.getBindingResult().getAllErrors()
                .stream()
                .map(ObjectError::getDefaultMessage)
                .collect(Collectors.toList());
        return Error.of(Error.PARA_ERROR_CODE, defaultMsg.get(0));
    }

    @ExceptionHandler({MethodArgumentNotValidException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    Error validationHandler(MethodArgumentNotValidException ex) {
        List<FieldError> fieldErrors = ex.getBindingResult().getFieldErrors();
        FieldError fr = fieldErrors.get(fieldErrors.size() - 1);
        return Error.of(Error.PARA_ERROR_CODE, fr.getDefaultMessage());
    }

    /**
     * 无访问权限
     *
     * @param ex
     * @return
     */
    @ExceptionHandler({UnauthorizedException.class, AuthorizationException.class})
    @ResponseStatus(HttpStatus.FORBIDDEN)
    @ResponseBody
    Error authHandler(AuthorizationException ex) {
        return Error.of(Error.AUTH_ERROR_CODE, "无权限访问");
    }

    /**
     * token失效，需要重新登录
     *
     * @param ex
     * @return
     */
    @ExceptionHandler({AuthenticationException.class})
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ResponseBody
    Error authHandler(AuthenticationException ex) {
        log.error("No auth", ex);
        return Error.of(Error.AUTH_ERROR_CODE, "No auth");
    }

    /**
     * 错误统一处理
     *
     * @param ex
     * @return
     * @throws Exception
     */
    @ExceptionHandler
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
    Error defaultExceptionHandler(Exception ex, final ServletRequest request) throws Exception {
        log.error("system error", ex);
        if (request != null && request instanceof ContentCachingRequestWrapper) {
            ContentCachingRequestWrapper wrapper = (ContentCachingRequestWrapper) request;
            String body =
                    new String(
                            wrapper.getContentAsByteArray(), Charset.forName(wrapper.getCharacterEncoding()));
            log.error(
                    "REQ PATH:{},BAD_REQUEST_BODY:{}, ERROR:{}",
                    wrapper.getServletPath(),
                    body,
                    ex.getMessage());
        }
        return Error.of(Error.SERVER_ERROR_CODE, "系统错误");
    }
}
