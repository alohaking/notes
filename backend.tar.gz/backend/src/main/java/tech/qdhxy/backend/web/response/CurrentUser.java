package tech.qdhxy.backend.web.response;

import lombok.Data;
import tech.qdhxy.backend.domain.User;

@Data
public class CurrentUser {
    private Long id;
    private String account;
    private String name;

    public static CurrentUser of(User user) {
        CurrentUser currentUser = new CurrentUser();
        currentUser.setId(user.getId());
        currentUser.setAccount(user.getAccount());
        currentUser.setName(user.getName());
        return currentUser;
    }
}
