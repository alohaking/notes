package tech.qdhxy.backend.config;

import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.mgt.SessionStorageEvaluator;
import org.apache.shiro.realm.Realm;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.spring.web.config.DefaultShiroFilterChainDefinition;
import org.apache.shiro.spring.web.config.ShiroFilterChainDefinition;
import org.apache.shiro.web.mgt.DefaultWebSessionStorageEvaluator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import tech.qdhxy.backend.service.UserService;
import tech.qdhxy.backend.shiro.DbRealm;
import tech.qdhxy.backend.shiro.JWTShiroRealm;
import tech.qdhxy.backend.shiro.JwtAuthFilter;

import javax.servlet.Filter;
import java.util.Map;

@Configuration
public class ShiroConf {

    @Bean("dbRealm")
    public Realm dbRealm(UserService userService){
        return new DbRealm(userService);
    }

    @Bean("jwtRealm")
    public Realm jwtRealm(UserService userService) {
        return new JWTShiroRealm(userService);
    }

    /**
     * 禁用session
     *
     * @return
     */
    @Bean
    protected SessionStorageEvaluator sessionStorageEvaluator() {
        DefaultWebSessionStorageEvaluator sessionStorageEvaluator =
                new DefaultWebSessionStorageEvaluator();
        sessionStorageEvaluator.setSessionStorageEnabled(false);
        return sessionStorageEvaluator;
    }

    /**
     * 因为要做token的登录验证，所以需要在filter链中加入自定义的token filter
     *
     * @param securityManager
     * @return
     */
    @Bean("shiroFilterFactoryBean")
    public ShiroFilterFactoryBean shiroFilter(SecurityManager securityManager) {
        ShiroFilterFactoryBean factoryBean = new ShiroFilterFactoryBean();
        factoryBean.setSecurityManager(securityManager);
        Map<String, Filter> filterMap = factoryBean.getFilters();
        filterMap.put("authcToken", new JwtAuthFilter());
        factoryBean.setFilters(filterMap);
        factoryBean.setFilterChainDefinitionMap(shiroFilterChainDefinition().getFilterChainMap());
        return factoryBean;
    }

    /**
     * path和登录、权限验证的对应关系
     *
     * @return
     */
    @Bean("shiroFilterChainDefinition")
    protected ShiroFilterChainDefinition shiroFilterChainDefinition() {
        DefaultShiroFilterChainDefinition chainDefinition = new DefaultShiroFilterChainDefinition();
        chainDefinition.addPathDefinition("/api/login", "noSessionCreation,anon"); // 登录
        chainDefinition.addPathDefinition("/api/wx/**", "noSessionCreation,anon"); // 微信相关的接口
        chainDefinition.addPathDefinition("/page/**", "noSessionCreation,anon"); 
        chainDefinition.addPathDefinition("/api/logout", "noSessionCreation,authcToken[permissive]"); // 登出
        chainDefinition.addPathDefinition("/**", "noSessionCreation,authcToken");


        // 静态资源
        chainDefinition.addPathDefinition("/js/**", "noSessionCreation,anon");
        chainDefinition.addPathDefinition("/css/**", "noSessionCreation,anon");
        chainDefinition.addPathDefinition("/plugin/**", "noSessionCreation,anon");
        return chainDefinition;
    }
}
