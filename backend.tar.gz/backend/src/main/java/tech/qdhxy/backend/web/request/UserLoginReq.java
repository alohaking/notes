package tech.qdhxy.backend.web.request;

import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotBlank;

@Data
@ToString
public class UserLoginReq {
    @NotBlank
    private String account;
    @NotBlank
    private String password;
}
